# Multiverse Models and AI

## Overview
Recent research categorizes multiverse theories into nine major types, highlighting the non-local nature of informational branching.

## Key Concepts
- **9 Multiverse Types**: Inflationary, quantum, holographic, etc.
- **AI Generating Multiverses**: Language models as probabilistic multiverse generators.

## Research Directions
- Use AI to track coherence between branches.
- Identify emergent patterns across simulated universes.

## Sources
[2] Probability and Philosophical Value of Multiverse Theories: https://www.jsr.org/hs/index.php/path/article/view/3554
[6] Language models as multiverse generators: https://generative.ink/posts/language-models-are-multiverse-generators/
