# Generalized Probabilistic Theories (GPT) in Physics

## Overview
GPTs offer a framework for exploring physics beyond classical and quantum mechanics.

## Key Concepts
- **Non-classical correlations**: Go beyond Bell inequalities.
- **Framework Applications**: Useful for formulating quantum gravity models.

## Research Directions
- Apply GPTs to model spacetime emergence.
- Explore alternative causal structures.

## Sources
[5] Diagrams and GPTs for Quantum Gravity: https://quantum-journal.org/views/qv-2024-01-08-78/
[28] Generalized probabilistic theory - Wikipedia: https://en.wikipedia.org/wiki/Generalized_probabilistic_theory
